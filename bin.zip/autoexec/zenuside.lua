game:GetService("StarterGui"):SetCore("SendNotification",{
Title = "Zenus V2",
Text = "Zenus Attached! Powered by Nezur.", 

Button1 = "ignore",
Duration = 60 
})